package com.wellsfargo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CodeBotUserApplication {

	public static void main(String[] args) {
		SpringApplication.run(CodeBotUserApplication.class, args);
	}

}
