package com.wellsfargo.model;

public class userRoleModel {
	private	String  usernamerole;
	private String  role;
	public String getUsernamerole() {
		return usernamerole;
	}
	public void setUsernamerole(String usernamerole) {
		this.usernamerole = usernamerole;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
}
